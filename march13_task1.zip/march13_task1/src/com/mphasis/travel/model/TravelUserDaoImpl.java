package com.mphasis.travel.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TravelUserDaoImpl {
	public int create(TravelUser user) throws ClassNotFoundException, SQLException
	{
		//signup
		Connection con=ConnectionFactory.getConnection();
		PreparedStatement st=con.prepareStatement("INSERT INTO TRAVEL_USER VALUES(?,?,?,?)");
		st.setString(1, user.getUserID());
		st.setString(2, user.getUserName());
		st.setString(3, user.getPassword());
		st.setString(4, user.getRole());
		int no=st.executeUpdate();
		return no;
		
	}
	public TravelUser validate(String userId,String password) throws ClassNotFoundException, SQLException {
		//login
		Connection con=ConnectionFactory.getConnection();
		PreparedStatement st=con.prepareStatement("SELECT * FROM TRAVEL_USER WHERE USER_ID=? AND PASSWORD=?");
		st.setString(1, userId);
		st.setString(2,password);
		ResultSet rs=st.executeQuery();
		int no=0;
		TravelUser user=null;
		while(rs.next())
		{
			user=new TravelUser(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			no++;
		}
		if(no!=1)
		{
			return null;
		}
		else
			return user;
		
	}
	
	

}
