package com.mphasis.travel.model;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.apache.tomcat.util.codec.binary.Base64;

public class Travel {
	private Integer travelId;
	private String placeName;
	private Date dateOfJourney;
	private int pricePackage;
	private byte[] placeImage;
	transient SimpleDateFormat sdf;
	transient SimpleDateFormat sdf2;
	 public Travel(){
		 
		 sdf=new SimpleDateFormat("dd-MMM-yy");
			sdf2=new SimpleDateFormat("yyyy-MM-dd");
	 }
	public Travel(Integer travelId, String placeName, Date dateOfJourney, int pricePackage, byte[] placeImage) {
		this();
		this.travelId = travelId;
		this.placeName = placeName;
		this.dateOfJourney = dateOfJourney;
		this.pricePackage = pricePackage;
		this.placeImage = placeImage;
	}
	public Integer getTravelId() {
		return travelId;
	}
	public void setTravelId(Integer travelId) {
		this.travelId = travelId;
	}
	public String getPlaceName() {
		return placeName;
	}
	public void setPlaceName(String placeName) {
		this.placeName = placeName;
	}

	public Date getDateOfJourney() {
		return dateOfJourney;
	}
	public String getDateOfJourney1() {
		return sdf.format(dateOfJourney);
	}

	public String getDateOfJourney2() {
		return sdf2.format(dateOfJourney);
	}

	public void setDateOfJourney(Date dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public int getPricePackage() {
		return pricePackage;
	}
	public void setPricePackage(int pricePackage) {
		this.pricePackage = pricePackage;
	}
	public byte[] getPlaceImage() {
		return placeImage;
	}
	public String getplaceImage1()
	{
		String x=Base64.encodeBase64String(placeImage);
		return x;
	}
	public void setPlaceImage(byte[] placeImage) {
		this.placeImage = placeImage;
	}
	@Override
	public String toString() {
		return "Travel [travelId=" + travelId + ", placeName=" + placeName + ", dateOfJourney=" + dateOfJourney
				+ ", pricePackage=" + pricePackage + ", placeImage=" + placeImage.length + "]";
	}
	 
	

}
