package com.mphasis.travel.model;

public class TravelUser {
	private String userID;
	private String userName;
	private String password;
	private String role;
	public TravelUser() {}
	
	
	public TravelUser(String userID, String userName, String password, String role) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "TravelUser [userID=" + userID + ", userName=" + userName + ", password=" + password + ", role=" + role
				+ "]";
	}
	
	
	

}
