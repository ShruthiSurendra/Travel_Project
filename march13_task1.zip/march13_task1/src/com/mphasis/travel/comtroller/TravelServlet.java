package com.mphasis.travel.comtroller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.mphasis.travel.model.Travel;
import com.mphasis.travel.model.TravelDaoImpl;

/**
 * Servlet implementation class TravelServlet
 */
@WebServlet({ "/TravelServlet", "/travel" })
@MultipartConfig
public class TravelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TravelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//		String btn=request.getParameter("btn");
//		
//		Integer travelId=Integer.valueOf(request.getParameter("travelId"));
//		String placeName="";
//		String sdate="";
//		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
//		Date dateOfJourney=null;
//		Travel travel =null;
//		TravelDaoImpl tdao=new TravelDaoImpl();
//		int no=0;
//		if(btn.equals("Add") || btn.equals("Modify"))
//		{
//			placeName=request.getParameter("placeName");
//			sdate=request.getParameter("dateOfJourney");
//			
//			try {
//				dateOfJourney=sdf.parse(sdate);
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			if(dateOfJourney==null)
//				return;
//			
//			Integer pricePackage=Integer.valueOf(request.getParameter("pricePackage"));
//			travel=new Travel(travelId,placeName,  dateOfJourney, pricePackage, null);
//		}
//		switch(btn)
//		{
//		case "Add":
//			if(travel!=null)
//			{
//				try {
//					no=tdao.create(travel);
//				} catch (ClassNotFoundException | SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				System.out.println(no+" row inserted");
//			}
//			break;
//		case "Modify":
//			if(travel!=null)
//			{
//				try {
//					no=tdao.update(travel);
//				} catch (ClassNotFoundException | SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				System.out.println(no+" row updated");
//			}
//			break;
//		case "Delete":
//			try {
//				no=tdao.delete(travelId);
//			} catch (ClassNotFoundException | SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			System.out.println(no+" row delete");
//			break;
//		}
//		//redirect back to jsp again
//		response.sendRedirect("travel.jsp");
//		response.getWriter().print("added");
//		
	}
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
//String btn=request.getParameter("btn");
//		
//		Long associateId=Long.valueOf(request.getParameter("associateId"));
//		String firstName="";
//		String lastName="";
//		String sdate="";
//		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
//		Date dateOfJoining=null;
//		String gender="";
//		Associate associate=null;
//		AssociateDaoImpl adao=new AssociateDaoImpl();
//		int no=0;
//		if(btn.equals("Add") || btn.equals("Modify"))
//		{
//			firstName=request.getParameter("firstName");
//			lastName=request.getParameter("lastName");
//			sdate=request.getParameter("dateOfJoining");
//			
//			try {
//				dateOfJoining=sdf.parse(sdate);
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			if(dateOfJoining==null)
//				return;
//			
//			gender=request.getParameter("gender");
//			//code for accessing file contents as byte array
//			Part part = request.getPart("picture");
//			InputStream is = part.getInputStream();
//			int len = is.available();
//			byte []picture=new byte[len];
//			is.read(picture);
//			
//			associate=new Associate(associateId, firstName, lastName, dateOfJoining, gender, picture);
//		}
//		switch(btn)
//		{
//		case "Add":
//			if(associate!=null)
//			{
//				try {
//					no=adao.create(associate);
//				} catch (ClassNotFoundException | SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				System.out.println(no+" row inserted");
//			}
//			break;
//		case "Modify":
//			if(associate!=null)
//			{
//				try {
//					no=adao.update(associate);
//				} catch (ClassNotFoundException | SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				System.out.println(no+" row updated");
//			}
//			break;
//		case "Delete":
//			try {
//				no=adao.delete(associateId);
//			} catch (ClassNotFoundException | SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			System.out.println(no+" row delete");
//			break;
//		}
//		//redirect back to jsp again
//		response.sendRedirect("associate2.jsp");
//
//	}
		String btn=request.getParameter("btn");
	 Integer  travelId=Integer.valueOf(request.getParameter("travelId"));
			  
		
		String placeName="";
		String sdate="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date dateOfJourney=null;
		Travel travel =null;
		TravelDaoImpl tdao=new TravelDaoImpl();
		int no=0;
		if(btn.equals("Add") || btn.equals("Modify"))
		{
			placeName=request.getParameter("placeName");
			sdate=request.getParameter("dateOfJourney");
			
			try {
				dateOfJourney=sdf.parse(sdate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(dateOfJourney==null)
				return;
			Part part = request.getPart("placeImage");
			InputStream is = part.getInputStream();
			int len = is.available();
			byte []placeImage=new byte[len];
			is.read(placeImage);
			
			Integer pricePackage=Integer.valueOf(request.getParameter("pricePackage"));
			travel=new Travel(travelId,placeName,  dateOfJourney, pricePackage, placeImage);
		}
		switch(btn)
		{
		case "Add":
			if(travel!=null)
			{
				try {
					no=tdao.create(travel);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(no+" row inserted");
			}
			break;
		case "Modify":
			if(travel!=null)
			{
				try {
					no=tdao.update(travel);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(no+" row updated");
			}
			break;
		case "Delete":
			try {
				no=tdao.delete(travelId);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(no+" row delete");
			break;
		}
		//redirect back to jsp again
	   response.sendRedirect("ActualTravel.jsp");
//		response.getWriter().print("added");

}
}
